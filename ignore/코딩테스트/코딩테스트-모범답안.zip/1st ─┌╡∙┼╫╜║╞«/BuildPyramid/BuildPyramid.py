def solution(n):
    """
    :param n: int
    :return: int
    """

    return (1 + n) * n / 2
