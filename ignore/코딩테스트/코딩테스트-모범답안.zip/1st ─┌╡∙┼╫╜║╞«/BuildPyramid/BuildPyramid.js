/**
 * @param n {number}
 * @returns {number}
 */
function solution(n) {
  return (1 + n) * n / 2
}

export default solution