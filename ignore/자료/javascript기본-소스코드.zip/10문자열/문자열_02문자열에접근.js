const str = 'ABC';
str.charAt(2);
str[2];

const paragraph =
	'The quick brown fox jumps over the lazy dog. If the dog barked, was it really lazy?';
const searchTerm = 'dog';

paragraph.includes(searchTerm);
paragraph.indexOf(searchTerm);
paragraph[40];
paragraph[41];
paragraph[42];
