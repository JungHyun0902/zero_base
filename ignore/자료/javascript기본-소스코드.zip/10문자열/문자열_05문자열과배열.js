'HELLO,WORLD'.split(',');

['HELLO', 'WORLD'].join('');

[...'HELLO WORLD'];

'HELLO WORLD'.length;
['1', 2, 3].length;
