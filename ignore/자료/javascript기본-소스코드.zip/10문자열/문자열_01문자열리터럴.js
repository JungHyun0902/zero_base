const singleQuote = '';
const doubleQuote = "";
const multiLine = "1\
2\
3\
4\
";


// ES2015+
const backQuote = `
1
2
3
4
5`;


const empty = null;
console.log(empty + 'hello')