/**
 * 식별자(예약어)
 * 
 * 1. 문자열 시작
 * 2. 언어의 내장 예약어와 중복 피해야함
 */

const _temp = lodash;
underscore;
const $jQuery = 10;


function function() {
  
}

function()

function test() {
  
}

test()