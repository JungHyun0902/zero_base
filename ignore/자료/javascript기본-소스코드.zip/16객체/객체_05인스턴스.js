/**
 * 인스턴스
 */
const me = {
	name: 'jang',
	age: 10,
	location: 'korea',
};

const me2 = {
	name: 'jang',
	age: 10,
	location: 'korea',
};

const you = {
	name: 'seok',
	age: 20,
	location: 'Germany',
};

console.log(me === me2);
console.log(me === you);
