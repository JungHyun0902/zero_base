function hello() {
	return 'hello';
}

export default hello;
