import * as i from './05-es-module-export.js';

console.log(i.a);
console.log(i.hello());
