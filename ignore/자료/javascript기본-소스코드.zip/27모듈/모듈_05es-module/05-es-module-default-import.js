import h from './05-es-module-default-export';

console.log(h());
