const a = 'a';

function hello() {
	return 'hello';
}

export { a, hello };
