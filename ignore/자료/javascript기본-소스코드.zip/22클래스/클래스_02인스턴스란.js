/**
 * 인스턴스란
 */
const me = {
	name: 'jang',
	age: 10,
	location: 'korea',
};

function Func() {}

class Classs {}

const newInstance = new Func();
const newInstance2 = new Classs();
