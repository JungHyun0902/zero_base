/**
 * 클래스란
 */
function Person(name, age) {
	this.name = name;
	this.age = age;
}

class Person {
	constructor(name, age) {
		this.name = name;
		this.age = age;
	}
}
