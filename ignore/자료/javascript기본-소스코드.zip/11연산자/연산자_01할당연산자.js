/**
 * 할당 연산자
 */

let x;

// 이미 선언된 변수에 할당
x = '';

// 변수를 선언 & 할당 => 초기화
let y = '';

const obj = {};

obj.prop1 = '';
obj.prop2 = {};
obj.prop3 = [];
obj.prop = function () {};

const arr = [];
arr[0] = 0;
arr[1] = 1;
