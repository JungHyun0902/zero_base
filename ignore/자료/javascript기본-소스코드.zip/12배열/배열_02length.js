/**
 * length
 */

const arr = [1, 2, 3];

arr[9] = undefined;

arr.length = 20;

// 초기화
arr.length = 0;
