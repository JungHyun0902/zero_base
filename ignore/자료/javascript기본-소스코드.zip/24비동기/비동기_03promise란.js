/**
 * Promise
 */
const promiseResolve = Promise.resolve('성공');
const promiseReject = Promise.reject('실패');
