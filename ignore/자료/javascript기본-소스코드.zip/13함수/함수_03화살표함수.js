const arrowFunc = () => {
	/**
	 * 1. argument
	 * 2. this
	 */
	return '문자열';
};

const arrowFunc2 = () => '문자열';
