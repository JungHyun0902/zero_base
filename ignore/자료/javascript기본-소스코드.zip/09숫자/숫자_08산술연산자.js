/**
 * # 산술 연산자
 * + - / * %
 */

2 - 1;
10 / 5;
10 % 2;
2 * 2;

let x = 5;

x--;
x = x - 1;

x++;
x = x + 1;

for (; ; ;) {

}

// 괄호로 인해 실행 순서가 바뀜
console.log(3 + (10 * 2));
console.log((3 + 10) * 2);

const isTicketPrice = 3 + 10

if (3 + (10 * 2)) {

}
if (isTicketPrice * 2) {

}