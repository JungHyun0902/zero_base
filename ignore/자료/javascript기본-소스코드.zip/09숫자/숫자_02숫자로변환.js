console.log(undefined);
console.log(null);
console.log('');
console.log('String');
console.log(true);
console.log(false);
console.log(3.141592);

if (1 == true) {
	console.log('참');
}

console.log(+true);
console.log(+false);

const strNumber = '11111';

if (Number(strNumber)) {
	console.log('실행');
}
