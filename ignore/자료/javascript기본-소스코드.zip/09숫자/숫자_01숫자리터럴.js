/**
 * 숫자 리터럴
 */

35;
3.141;
0xff;
5e2;

const num = 123.111;
num.toFixed;

new Number(123);
