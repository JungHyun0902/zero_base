/**
 * Bigint
 *
 * 안정적인 범위의 정수
 */

console.log(Number.MAX_VALUE);
console.log(Number.MIN_SAFE_INTEGER);
console.log(123123123123123123123123123123123n);
console.log(
	BigInt(123123123123123123123123123123123),
);
