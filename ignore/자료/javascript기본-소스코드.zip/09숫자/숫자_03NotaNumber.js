/**
 * Not a Number => 숫자가 아니다
 * - NaN
 * - Number.NaN
 */

Number(undefined);
parseInt('숫자로 변환 불가능한 문자열');
Math.log(-1);
10 + NaN;
'가나다라' / 10;
